<?php
require('config.php');
$price = $_GET['price'];
$doctor = $_GET['doctor'];

?>
<form action="submit.php" method="post" style="margin: auto; width: 220px;">
    <div class="description">
          <h3>Doctor Appointment</h3>
          <h5>$50.00</h5>
        </div>
	<script
		src="https://checkout.stripe.com/checkout.js" class="stripe-button"
		data-key="<?php echo $publishableKey?>"
		data-amount= $price
		data-name= "Doctor"
		data-description="Appointment Payment"
		<!--data-image="https://www.logostack.com/wp-content/uploads/designers/eclipse42/small-panda-01-600x420.jpg"-->
		data-currency="usd"
		data-email="phpvishal@gmail.com"
	>
	</script>

</form>








<!DOCTYPE html>
<!--<html>-->
<!--  <head>-->
<!--    <title>Buy cool new product</title>-->
    <!--<link rel="stylesheet" href="style.css">-->
<!--    <script src="https://polyfill.io/v3/polyfill.min.js?version=3.52.1&ampfeatures=fetch"></script>-->
<!--    <script src="https://js.stripe.com/v3/"></script>-->
<!--  </head>-->
<!--  <body>-->
<!--    <section>-->
<!--      </div>-->
<!--<form action="submit.php" method="post" style="margin: auto; width: 220px;">-->
<!--    <div class="description">-->
<!--          <h3>Doctor Appointment</h3>-->
<!--          <h5>$50.00</h5>-->
<!--        </div>-->
<!--	<script-->
<!--		src="https://checkout.stripe.com/checkout.js" class="stripe-button"-->
<!--		data-key="<?php echo $publishableKey?>"-->
<!--		data-amount= $price-->
<!--		data-name= "$doctor"-->
<!--		data-description="Programming with Vishal Desc"-->
		<!--data-image="https://www.logostack.com/wp-content/uploads/designers/eclipse42/small-panda-01-600x420.jpg"-->
<!--		data-currency="usd"-->
<!--		data-email="phpvishal@gmail.com"-->
<!--	>-->
<!--	</script>-->

<!--</form>-->
<!--</section>-->

<!--  </body>-->
<!--</html>-->