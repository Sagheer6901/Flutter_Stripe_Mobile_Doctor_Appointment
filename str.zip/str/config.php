<?php
require('stripe-php-master/init.php');

$publishableKey="pk_test_51LPR8aJnydkqJuAqCYFF2R9HU6mXWsujgrWkxQm1nizkfR3n7eZ7eQSjbysxuFBAhSzke1qCCIYgPj4A2gn3IrVA007p1JczLk";

$secretKey="sk_test_51LPR8aJnydkqJuAqx0t0yoeoXQNblqNODS4ZsoHZIqSjMYRgjF3fwXU9CkmxQY7lnk1iA3DhpQtn9W5mfo2kzihX00xfeW0aYR";

\Stripe\Stripe::setApiKey($secretKey);
?>