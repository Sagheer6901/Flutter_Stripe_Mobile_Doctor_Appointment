<?php
require('config.php');
// echo '<pre>';
// print_r($_POST);

if(isset($_POST['stripeToken'])){
    
	\Stripe\Stripe::setVerifySslCerts(false);

	$token=$_POST['stripeToken'];

	$data=\Stripe\Charge::create(array(
		"amount"=>1000,
		"currency"=>"usd",
		"description"=>"Programming with Vishal Desc",
		"source"=>$token,
	));
    //  echo 'true';

// 	echo "<pre>";
// 	print_r($data);
}
?>
<form action="submit.php" method="post" style="margin: auto; width: 220px;">
    <div class="description">
          <h1>Payment Successful</h3>
        </div>

</form>